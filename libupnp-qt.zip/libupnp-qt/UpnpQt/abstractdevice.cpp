#include "upnpabstractdevice.h"

UpnpAbstractDevice::UpnpAbstractDevice()
{

}
