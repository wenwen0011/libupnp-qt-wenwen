#ifndef UPNPABSTRACTDEVICE_H
#define UPNPABSTRACTDEVICE_H


class UpnpAbstractDevice
{
public:
    UpnpAbstractDevice();
};

#endif // UPNPABSTRACTDEVICE_H
